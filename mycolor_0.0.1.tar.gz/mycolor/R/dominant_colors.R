#' @title dominant color
#' @description
#' Extract representative colors from the image
#'
#' @param image_path The address of the PNG image
#' @param k The number of generated colors
#' @param nowhite Whether to remove the very white color?
#' The purpose is to remove any possible background color.
#'
#' @returns A vector that includes colors
#'
#' @examples
#' color_c <- dominant_colors(
#' image_path="pic.png", k = 5, nowhite = T)
#' @author Full sugar white bread rolls
#' @importFrom png readPNG
#' @export
dominant_colors <- function(image_path, k = 5,nowhite = T) {
  # 读取PNG图像
  img <- readPNG(image_path)

  # 处理图像数据
  img_dim <- dim(img)

  # 提取RGB通道（忽略Alpha通道）
  if (img_dim[3] == 4) {
    rgb_data <- img[, , 1:3]
  } else {
    rgb_data <- img
  }

  # 将三维数组转换为二维数据框
  pixels_df <- data.frame(
    x = rep(1:img_dim[2], each = img_dim[1]),
    y = rep(img_dim[1]:1, times = img_dim[2]),
    R = as.vector(rgb_data[, , 1]),
    G = as.vector(rgb_data[, , 2]),
    B = as.vector(rgb_data[, , 3])
  )

  # 执行K-means聚类
  set.seed(123)  # 确保结果可重现
  kmeans_result <- kmeans(pixels_df[, c("R", "G", "B")], centers = k)

  # 提取聚类中心作为代表色
  dominant_colors <- kmeans_result$centers
  dominant_colors_hex <- apply(dominant_colors, 1, function(color) {
    rgb(color[1], color[2], color[3])
  })
  if (nowhite) {
    pattern <- "^.(F).(F).(F)"
    condition <- grepl(pattern, dominant_colors_hex)
    dominant_colors_hex <- dominant_colors_hex[!condition]
  }
  # 返回结果
  unname(dominant_colors_hex)
  return(dominant_colors_hex)
}
