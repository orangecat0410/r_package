#' @title mycolor2
#' @description
#' A function for selecting colors from a color list
#'
#' @param yourcolor It is a list containing colors
#' (must be 6-digit 16-bit
#' hexadecimal color codes starting with #)
#' @param NUM The quantity of the color you need
#' (The quantity must be less than
#' the number of colors in the vector.)
#' @param source "raw" represents the original order,
#' "level" represents the color gradation order,
#' and "depth" represents the order of color intensity.
#' @param selection "radom"or"Equidistant"or"neighbor"
#' @param seed NA or number
#' @param start_pre NA OR a floating-point number ranging from 0 to 1
#' @examples color_c = mycolor2(yourcolor = color_c, NUM=40, source = "raw", selection = "neighbor", seed=NA, start_pre=NA)
#' @returns A list containing color vectors
#' @export
#'
mycolor2 = function(yourcolor = color, NUM = 40, source = "level", selection = "radom", seed = 123,start_pre=0.5){
  if (class(yourcolor)=="character"){
    color <- yourcolor
  }else {
    color <- c(
      "#C6A9A1", "#5D4C44", "#C5BAB8", "#D1C4B3", "#5E4042", "#A28A86", "#A08B86", "#676C66", "#708E98", "#8A938E", "#54615A",
      "#DFEBEB", "#A8ABA4", "#A8AAA5", "#8B6773", "#855B67", "#B6BCCA", "#C1B5BF", "#FDE0E4", "#644453", "#78A495", "#8A926B",
      "#5D6C57", "#6E736D", "#E4E2C9", "#CFE1D3", "#995B70", "#846992", "#D4C0C2", "#624772", "#413158", "#E7D6C2", "#547FB6",
      "#C5D8E7", "#1F2D38", "#C1D2E2", "#424F60", "#D5E2F2", "#B6826D", "#8E5951", "#886349", "#F2E8E9", "#814D3F", "#E9BDA0",
      "#F3E7E9", "#509C82", "#73BEA0", "#C3F8E6", "#1B3C31", "#427370", "#99C2C8", "#DA7289", "#BF6074", "#CD5176", "#CC7888",
      "#CB94B1", "#B24057", "#BF6173", "#7A7579", "#DBD7D8", "#897B92", "#CDB97E", "#818C7C", "#DDD2BE", "#DCD7D3", "#7E90A6",
      "#D8D1E1", "#D1C0AC", "#CB9D7B", "#A59A96", "#EEEDEB", "#765953", "#F1DFDF", "#FFFAE8", "#D8D6D9", "#E7D8D5", "#6B696A",
      "#969696", "#C6CEE1", "#C5BCB7", "#DDD2BE", "#C9D9BE", "#E8E8DC", "#F1D9D9", "#9AA092", "#AE7681", "#A59A96", "#E1DBA1",
      "#F08771", "#BEB9B3", "#A54B43", "#FBEEDD", "#A1B1CB", "#DDDBCF", "#5A5E67", "#CBCBC9", "#ADA28E", "#A7997C", "#564D44",
      "#B3A8A4", "#BBBBB9", "#D8CFBE", "#6A5F65", "#826859", "#686A54", "#9C593E", "#B19E8F", "#B1886A", "#E3C2A1", "#BDA172",
      "#BAAE94", "#EDE1D1", "#89797C", "#816148", "#806248", "#E5E1D6", "#A3AAB4", "#ADA28E", "#DDDFDC", "#606153", "#C1C19D",
      "#D3AF5B", "#7A606B", "#9C9489", "#927371", "#B89052", "#A1834F", "#4B5B74", "#545A66", "#816E5F", "#C3C2C0", "#D3A46E",
      "#CCBEB3", "#7B6D4A", "#F7EED1", "#7A6248", "#C3C2BE", "#F1EADA", "#BC9D88", "#733E5A", "#5F6F65", "#D0B4A8", "#364B6A",
      "#797B88", "#B37C75", "#C7B398", "#EEEBC2", "#E1D3C8", "#A56A48", "#AA8251", "#CA9C4F", "#DED5C4", "#8D6A4A", "#73636D",
      "#53524E", "#B39F9E", "#D7BF9B", "#544E4E", "#68655E", "#E0D7D2", "#76676C", "#5B5147", "#9FA3A4", "#E4CFBE", "#F3F0E9",
      "#B58E57", "#6D5249", "#A28FA2", "#654945", "#53557C", "#9C8170", "#6E4D3E", "#A9866A", "#7B695B", "#BDB79F", "#AC9A5A",
      "#5A5B53", "#7F7C77", "#D6CBB9", "#A7A8A0", "#BDC0C9", "#D5ABBF", "#A18F81", "#E4E4E2", "#363B3E", "#646E63", "#B5A7A4",
      "#AF655A", "#81786F", "#875F5F", "#80684C", "#97998C", "#D69DA4", "#C5B4A0", "#CDA59D", "#A17D5D", "#A07D5D", "#47516A",
      "#465069", "#E8C2D9", "#8F7EAB", "#A0968A", "#7B695B", "#F3EAE5", "#E0C8B0", "#6B4F4C", "#927D78", "#E7DED9", "#AA8D7F",
      "#998881", "#C7BCB8", "#C39F7B", "#7E453A", "#CCCBB9", "#6F5E4E", "#CDC2C0", "#A47B75", "#665B57", "#CFD7B0", "#525751",
      "#E3E5E4", "#C0C0C0", "#E0D7D8", "#E1E6E0", "#B0B1B3", "#9DA9B7", "#B6C5B2", "#98A48C", "#949492", "#C4CCD7", "#656565",
      "#8797A7", "#DBDBD9", "#E7A884", "#E5A984", "#453F63", "#DACCDD", "#A971A0", "#A49BC6", "#73488F", "#656597", "#491E4C",
      "#B99FC6", "#87729D", "#7D5270", "#5E386B", "#503F61", "#9D91B9", "#652D86", "#E1885E", "#D56847", "#E2A380", "#DD6C42",
      "#D35A21", "#D4693F", "#DB7E5C", "#A94B32", "#C9654E", "#D87355", "#E5B8A1", "#DD9273", "#DEA681", "#D98267", "#9A4540",
      "#BC9E7C", "#C6803A", "#CB4047", "#C94048", "#CB7E3A", "#C93F4C", "#BC9F77", "#BC9E78", "#C47F34", "#9B443B", "#CB3F48",
      "#CB3F4C", "#C6803B", "#D0D1D5", "#B7C2B2", "#515257", "#4E6A76", "#517D7E", "#D1BCBB", "#515256", "#80623B", "#9F7736",
      "#5F4121", "#C29D59", "#595755", "#A08A6D", "#302D28", "#817B73", "#CBB189", "#4F564D", "#66736C", "#67361C", "#A7785B",
      "#1F2316", "#363E31", "#945335", "#CEA490", "#88928B", "#808DAA", "#F6B012", "#FCEB0A", "#1B387E", "#DB6610", "#EB9A3D",
      "#F6DC54", "#F7E09B", "#F1F1EA", "#F3CC8B", "#552379", "#4E512B", "#A45170", "#B07E9F", "#D7B2C7", "#E4A644", "#DE7117",
      "#826144", "#252527", "#195766", "#A1997B", "#425F62", "#194047", "#4B413A", "#C6BC99", "#7A7D6C", "#727066", "#888276",
      "#D2B68F", "#9C7C52", "#634424", "#CCC8C4", "#7E603A", "#3F240E", "#AF9C83", "#E5C0A0", "#6E513A", "#A87746", "#7A6454",
      "#3C3022", "#8F796A", "#C59C7B", "#272117", "#573F2C", "#875215", "#C4791D", "#A68A35", "#59441D", "#3C2913", "#8D752A",
      "#200E09", "#EDB43C", "#C1A141", "#3E4069", "#CF915A", "#938693", "#726F8E", "#5A597C", "#B39FA0", "#D1AA80", "#B28978",
      "#1E2347", "#90450B", "#B2620C", "#C1A03B", "#CA820A", "#F6EA2D", "#313A0D", "#6C7612", "#F1D20B", "#DDAE0B", "#2D659E",
      "#1D3D68", "#4E95C5", "#E0CF5B", "#1A1D29", "#E8EEBC", "#93CEDF", "#697764", "#9EB395", "#7082B2", "#100B11", "#624733",
      "#2D2323", "#EFDBCA", "#C5A376", "#323E59", "#455891", "#8F6C4B", "#719093", "#A98755", "#A23F25", "#D9E0D4", "#7B5F3F",
      "#CCB787", "#24221B", "#553221", "#3A504D"
    )
  }
  color_unique <- unique(color)
  #按照色阶排序-----------------------------------------
  # 转换为RGB矩阵
  rgb_matrix <- col2rgb(color_unique)

  # 转换为HSV空间 (返回3行N列的矩阵)
  hsv_matrix <- rgb2hsv(rgb_matrix)

  # 转置为数据框便于排序
  hsv_df <- as.data.frame(t(hsv_matrix))
  colnames(hsv_df) <- c("H", "S", "V")

  # 按色相(H)排序 -> 饱和度(S)降序 -> 明度(V)降序
  sorted_index <- order(hsv_df$H, -hsv_df$S, -hsv_df$V)

  # 创建排序后的颜色向量
  sorted_colors <- color_unique[sorted_index]
  #按照颜色深浅进行排序-------------------------------------
  # 加载颜色处理包
  library(scales)
  # 步骤1: 将16进制颜色转换为RGB矩阵
  rgb_matrix <- col2rgb(color_unique)
  # 步骤2: 计算每个颜色的明度值
  brightness <- 0.299 * rgb_matrix["red", ] +
    0.587 * rgb_matrix["green", ] +
    0.114 * rgb_matrix["blue", ]

  # 步骤3: 按明度值升序（由浅到深）排序，获取索引
  sorted_index <- order(brightness, decreasing = TRUE)  # 明度值高的（浅色）在前

  # 步骤4: 按索引重新排列颜色向量
  color_sorted <- color_unique[sorted_index]
  #---------------------------------------------------------
  if (source == "level"){
    colorlist = sorted_colors
  } else if(source == "depth") {
    colorlist = color_sorted
  }else {colorlist = color}

  if (selection == "Equidistant"){
    #基于颜色深浅
    # 计算步长并生成索引
    n <- length(colorlist)        # 原始向量长度
    step <- n / NUM                   # 抽样步长
    if (is.na(seed)){}else{set.seed(seed)}
    random_start <- sample(1:(range(step)-1), 1)
    indices <- seq(random_start, n, by = step)  # 等间隔索引（可能含小数）

    # 将索引转换为整数（因索引需为整数）
    indices <- as.integer(round(indices))  # 四舍五入取整

    # 抽取40个颜色值
    new_colors <- colorlist[indices]
    scales::show_col(new_colors)
  } else if (selection == "radom") {
    # 设置随机种子确保结果可复现（可选）
    if (is.na(seed)){}else{set.seed(seed)}
    # 从 colorlist 中无放回随机抽取 40 个颜色
    new_colors <- sample(colorlist, size = NUM, replace = FALSE)
    scales::show_col(new_colors)
  } else if (selection == "neighbor") {
    start_end = (length(colorlist)- NUM)-1
    if (is.na(seed)){}else{set.seed(seed)}
    radom_start = sample(1:start_end)
    indices <- c(radom_start:(radom_start + NUM - 1))
    new_colors <- colorlist[indices]
    scales::show_col(new_colors)
    if (is.na(start_pre)){

    }else{
      pre_start = range(start_pre*((length(colorlist)- NUM)-1))
      indices <- c(pre_start:(pre_start + NUM - 1))
      new_colors <- colorlist[indices]
      scales::show_col(new_colors)
    }
  }
  return(new_colors)
}

