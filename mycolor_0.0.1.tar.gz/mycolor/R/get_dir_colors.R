#' @title get dir colors
#' @description
#' Extract colors for all PNG images in a folder
#'
#' @param folder_path The address of the folder containing PNG image files
#' @param threshold Threshold for color proportion
#' (a floating-point number ranging from 0 to 1)
#' @param nowhite Whether to remove the very white color?
#' @param toc Whether to output the result as a vector? T/F
#'
#' @returns A list containing color vectors
#'
#' @examples color_list = get_dir_colors(folder_path = "pic",threshold = 0.01,nowhite = T)
#' @export
get_dir_colors <- function(folder_path = "pic",threshold = 0.01,nowhite = T, toc = F) {
  # 获取文件夹下所有PNG文件路径
  png_files <- list.files(
    path = folder_path,
    pattern = "\\.png$",
    ignore.case = TRUE,
    full.names = TRUE
  )

  # 创建空列表存储结果
  color_list <- vector("list", length(png_files))

  # 遍历处理每张图片
  for (i in seq_along(png_files)) {
    file <- png_files[i]
    tryCatch({
      # 提取代表色
      colors <- get_colors(file,threshold = threshold,nowhite = nowhite)
      scales::show_col(colors)
      # 获取文件名（不含路径）
      file_name <- basename(file)

      # 添加到列表
      color_list[[i]] <- colors
      names(color_list)[i] <- file_name

      # 打印进度
      cat(sprintf("已处理: %s (%d/%d)\n", file_name, i, length(png_files)))
    }, error = function(e) {
      warning(sprintf("处理文件 %s 时出错: %s", basename(file), e$message))
    })
  }
  if (toc) {
    combined_color <- c()
    for (i in c(1:length(color_list))) {
      # 动态获取向量（例如 c1, c2, ..., c9）
      current_vector <- color_list[[i]]
      combined_color <- c(combined_color, current_vector)
    }
    return(combined_color)
  }else{
    return(color_list)
  }
}
