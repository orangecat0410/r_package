#' @title get colors
#' @description
#' Extract the colors of a PNG image based on the threshold.
#'
#' @param file_path The address of the png image
#' @param threshold Threshold for color proportion
#' (a floating-point number ranging from 0 to 1)
#' @param nowhite Whether to remove the very white color?
#' @importFrom png readPNG
#' @returns A list containing color vectors
#'
#' @examples color_c <- get_colors(
#' file,threshold = 0.01, nowhite = T)
#' @export
get_colors <- function(file_path,threshold = 0.01, nowhite = T) {
  # 读取PNG图像
  img <- readPNG(file_path)

  # 获取图像维度并统一为RGB三维数组
  dims <- dim(img)
  if (length(dims) == 2) {  # 灰度图处理
    img_array <- array(0, dim = c(dims, 3))
    img_array[, , 1] <- img
    img_array[, , 2] <- img
    img_array[, , 3] <- img
  } else if (dims[3] == 4) {  # 带透明通道的彩色图
    img_array <- img[, , 1:3]
  } else {  # 标准RGB图
    img_array <- img
  }

  # 将像素数据转换为十六进制颜色代码
  pixel_matrix <- matrix(img_array, ncol = 3)
  hex_codes <- rgb(
    red   = pixel_matrix[, 1],
    green = pixel_matrix[, 2],
    blue  = pixel_matrix[, 3],
    maxColorValue = 1
  )

  # 统计颜色频率
  color_counts <- table(hex_codes)
  total_pixels <- length(hex_codes)
  threshold <- threshold * total_pixels  # 2%阈值

  # 筛选代表色
  dominant_idx <- which(color_counts >= threshold)
  if (length(dominant_idx) == 0) {
    return("没有代表色")
  }

  # 按频率降序返回代表色
  dominant_colors <- names(color_counts)[dominant_idx]
  sorted_colors <- dominant_colors[order(-color_counts[dominant_idx])]
  if (nowhite) {
    pattern <- "^.(F).(F).(F)"
    condition <- grepl(pattern, sorted_colors)
    sorted_colors <- sorted_colors[!condition]
  }
  unname(sorted_colors)
  return(sorted_colors)
}
