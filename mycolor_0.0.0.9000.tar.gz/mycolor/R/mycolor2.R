#' @title mycolor2
#' @description
#' A function for selecting colors from a color list
#'
#' @param yourcolor It is a list containing colors
#' (must be 6-digit 16-bit
#' hexadecimal color codes starting with #)
#' @param NUM The quantity of the color you need
#' (The quantity must be less than
#' the number of colors in the vector.)
#' @param source "raw" represents the original order,
#' "level" represents the color gradation order,
#' and "depth" represents the order of color intensity.
#' @param selection "radom"or"Equidistant"or"neighbor"
#' @param seed NA or number
#' @param start_pre NA OR a floating-point number ranging from 0 to 1
#' @examples color_c = mycolor2(yourcolor = color_c, NUM=40, source = "raw", selection = "neighbor", seed=NA, start_pre=NA)
#' @returns A list containing color vectors
#' @export
#'

mycolor2 = function(yourcolor = color, NUM = 40, source = "level", selection = "radom", seed = 123,start_pre=0.5){

  color <- yourcolor
  color_unique <- unique(color)
  #按照色阶排序-----------------------------------------
  # 转换为RGB矩阵
  rgb_matrix <- col2rgb(color_unique)

  # 转换为HSV空间 (返回3行N列的矩阵)
  hsv_matrix <- rgb2hsv(rgb_matrix)

  # 转置为数据框便于排序
  hsv_df <- as.data.frame(t(hsv_matrix))
  colnames(hsv_df) <- c("H", "S", "V")

  # 按色相(H)排序 -> 饱和度(S)降序 -> 明度(V)降序
  sorted_index <- order(hsv_df$H, -hsv_df$S, -hsv_df$V)

  # 创建排序后的颜色向量
  sorted_colors <- color_unique[sorted_index]
  #按照颜色深浅进行排序-------------------------------------
  # 加载颜色处理包
  library(scales)
  # 步骤1: 将16进制颜色转换为RGB矩阵
  rgb_matrix <- col2rgb(color_unique)
  # 步骤2: 计算每个颜色的明度值
  brightness <- 0.299 * rgb_matrix["red", ] +
    0.587 * rgb_matrix["green", ] +
    0.114 * rgb_matrix["blue", ]

  # 步骤3: 按明度值升序（由浅到深）排序，获取索引
  sorted_index <- order(brightness, decreasing = TRUE)  # 明度值高的（浅色）在前

  # 步骤4: 按索引重新排列颜色向量
  color_sorted <- color_unique[sorted_index]
  #---------------------------------------------------------
  if (source == "level"){
    colorlist = sorted_colors
  } else if(source == "depth") {
    colorlist = color_sorted
  }else {colorlist = color}

  if (selection == "Equidistant"){
    #基于颜色深浅
    # 计算步长并生成索引
    n <- length(colorlist)        # 原始向量长度
    step <- n / NUM                   # 抽样步长
    if (is.na(seed)){}else{set.seed(seed)}
    random_start <- sample(1:(range(step)-1), 1)
    indices <- seq(random_start, n, by = step)  # 等间隔索引（可能含小数）

    # 将索引转换为整数（因索引需为整数）
    indices <- as.integer(round(indices))  # 四舍五入取整

    # 抽取40个颜色值
    new_colors <- colorlist[indices]
    scales::show_col(new_colors)
  } else if (selection == "radom") {
    # 设置随机种子确保结果可复现（可选）
    if (is.na(seed)){}else{set.seed(seed)}
    # 从 colorlist 中无放回随机抽取 40 个颜色
    new_colors <- sample(colorlist, size = NUM, replace = FALSE)
    scales::show_col(new_colors)
  } else if (selection == "neighbor") {
    start_end = (length(colorlist)- NUM)-1
    if (is.na(seed)){}else{set.seed(seed)}
    radom_start = sample(1:start_end)
    indices <- c(radom_start:(radom_start + NUM - 1))
    new_colors <- colorlist[indices]
    scales::show_col(new_colors)
    if (is.na(start_pre)){

    }else{
      pre_start = range(start_pre*((length(colorlist)- NUM)-1))
      indices <- c(pre_start:(pre_start + NUM - 1))
      new_colors <- colorlist[indices]
      scales::show_col(new_colors)
    }
  }
  return(new_colors)
}

